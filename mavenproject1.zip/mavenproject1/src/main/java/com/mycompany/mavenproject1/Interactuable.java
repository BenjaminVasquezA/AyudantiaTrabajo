/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Sala-2-11-PC04
 */
public interface Interactuable{
    int getIdObjeto();

    void setIdObjeto(int idObjeto);

    String getNombreObjeto();

    void setNombreObjeto(String nombreObjeto);
}
